package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import android.os.Bundle;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13, b14, b15, b16;
    TextView t;
    String s = "";
    double solution = 0;
    ArrayList<String> ops = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        setContentView(R.layout.activity_main);

        b1 = findViewById(R.id.button1);
        b2 = findViewById(R.id.button2);
        b3 = findViewById(R.id.button3);
        b4 = findViewById(R.id.button4);
        b5 = findViewById(R.id.button5);
        b6 = findViewById(R.id.button6);
        b7 = findViewById(R.id.button7);
        b8 = findViewById(R.id.button8);
        b9 = findViewById(R.id.button9);
        b10 = findViewById(R.id.button10);
        b11 = findViewById(R.id.button11);
        b12 = findViewById(R.id.button12);
        b13 = findViewById(R.id.button13);
        b14 = findViewById(R.id.button14);
        b15 = findViewById(R.id.button15);
        b16 = findViewById(R.id.button16);
        t = findViewById(R.id.text);

        b1.setOnClickListener(this);
        b2.setOnClickListener(this);
        b3.setOnClickListener(this);
        b4.setOnClickListener(this);
        b5.setOnClickListener(this);
        b6.setOnClickListener(this);
        b7.setOnClickListener(this);
        b8.setOnClickListener(this);
        b9.setOnClickListener(this);
        b10.setOnClickListener(this);
        b11.setOnClickListener(this);
        b12.setOnClickListener(this);
        b13.setOnClickListener(this);
        b14.setOnClickListener(this);

        b16.setOnClickListener(this);
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.button1:
                s += b1.getText().toString();
                t.setText(s);
                break;
            case R.id.button2:
                s += b2.getText().toString();
                t.setText(s);
                break;
            case R.id.button3:
                s += b3.getText().toString();
                t.setText(s);
                break;
            case R.id.button4:
                s += b4.getText().toString();
                t.setText(s);
                break;
            case R.id.button5:
                s += b5.getText().toString();
                t.setText(s);
                break;
            case R.id.button6:
                s += b6.getText().toString();
                t.setText(s);
                break;
            case R.id.button7:
                s += b7.getText().toString();
                t.setText(s);
                break;
            case R.id.button8:
                s += b8.getText().toString();
                t.setText(s);
                break;
            case R.id.button9:
                s += b9.getText().toString();
                t.setText(s);
                break;
            case R.id.button10:
                s += b10.getText().toString();
                t.setText(s);
                break;
            case R.id.button11:
                s += b11.getText().toString();
                t.setText(s);
                break;
            case R.id.button12:
                s += b12.getText().toString();
                t.setText(s);
                break;
            case R.id.button13:
                s = "";
                t.setText(null);
                ops.clear();
                solution = 0;

                break;
            case R.id.button14:
                s += b14.getText().toString();
                t.setText(s);
                break;

            case R.id.button16:
                s += b16.getText().toString();
                t.setText(s);
                break;
        }
    }

    public void equals(View v) {

        try {
            StringTokenizer tokenizer = new StringTokenizer(s, "/*-+", true);

            while (tokenizer.hasMoreTokens()) {
                ops.add(tokenizer.nextToken());
            }


            for (int i = 0; i < ops.size(); i++) {
                if (ops.get(i).equals("*") || ops.get(i).equals("/")) {
                    if (ops.get(i).equals("*")) {
                        solution = Double.parseDouble(ops.get(i - 1)) * Double.parseDouble(ops.get(i + 1));

                    } else if (ops.get(i).equals("/")) {
                        if(ops.get(i+1).equals("0"))
                            throw new ArithmeticException();
                        solution = Double.parseDouble(ops.get(i - 1)) / Double.parseDouble(ops.get(i + 1));
                    }
                    ops.remove(i + 1);
                    ops.set(i, String.valueOf(solution));
                    ops.remove(i - 1);
                    i=0;
                }
            }

            /* lower precedence * and / */
            for (int i = 0; i < ops.size(); i++) {
                if (ops.get(i).equals("+") || ops.get(i).equals("-")) {
                    Log.d("i",ops.get(i));
                    if (ops.get(i).equals("+")) {
                        solution = Double.parseDouble(ops.get(i - 1)) + Double.parseDouble(ops.get(i + 1));

                    } else if (ops.get(i).equals("-")) {
                        solution = Double.parseDouble(ops.get(i - 1)) - Double.parseDouble(ops.get(i + 1));
                    }
                    ops.remove(i + 1);
                    ops.set(i, String.valueOf(solution));
                    ops.remove(i - 1);
                    i = 0;
                }
                t.setText(String.valueOf(solution));
                s = String.valueOf(solution);
            }

        } catch (Exception e) {
            t.setText("Error");
        }
    }
}













